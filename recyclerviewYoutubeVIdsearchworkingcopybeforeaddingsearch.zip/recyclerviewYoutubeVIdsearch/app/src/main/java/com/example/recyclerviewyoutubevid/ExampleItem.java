package com.example.recyclerviewyoutubevid;

public class ExampleItem {
    private String mImageUrl;
    private String mTitle;
    private String mCreator;
    private int mSocialRank;
    private int mLikes;

    public ExampleItem(String imageUrl, String creator, String title, int socialRank) {
    //public ExampleItem(String imageUrl, String creator, String title) {
        // the image url sent back by the url starts with http not https
        // picaso can only process the image url starts with https
        // so you need to rectify this problem before sent it to picasso
        mImageUrl = imageUrl.replace("http","https");
        if(mImageUrl.contains("httpss")){
            mImageUrl = mImageUrl.replace("httpss","https");
        }
        mCreator = creator;
        mSocialRank = socialRank;
       // mLikes = likes;
        mTitle = title;
    }

    public String getImageUrl() {
        return mImageUrl;
    }

    public String getTitle(){
        return mTitle;
    }

    public String getCreator() {
        return mCreator;
    }

    public int getSocialRank() {
        return mSocialRank;
    }

    public int getLikeCount() {
        return mLikes;
    }
}
